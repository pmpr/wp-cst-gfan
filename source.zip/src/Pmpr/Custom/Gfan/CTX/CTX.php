<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae868b94f7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\x61\x78\x6f\156\157\155\x79\x5f\163\151\156\x67\154\x65\137\x76\141\x6c\165\145\137\155\x6f\144\151\x66\171\x5f\151\x74\x65\155\163", [$this, "\x73\143\x6f\x61\x79\x61\x6d\165\171\161\147\x6b\143\x61\155\x67"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
