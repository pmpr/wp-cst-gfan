<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a4f27f9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\141\170\x6f\x6e\157\155\171\137\x73\x69\156\147\154\145\137\166\141\154\x75\x65\137\155\x6f\144\151\146\171\137\151\164\145\x6d\x73", [$this, "\x73\143\x6f\x61\x79\141\155\165\x79\161\x67\x6b\143\141\155\x67"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
