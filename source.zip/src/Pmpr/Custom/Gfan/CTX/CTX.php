<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe938571             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\x61\x78\157\x6e\x6f\x6d\171\137\163\x69\x6e\147\154\x65\x5f\x76\141\154\165\x65\137\155\x6f\144\151\146\171\137\x69\x74\145\155\x73", [$this, "\163\143\x6f\x61\x79\x61\155\x75\x79\161\x67\x6b\143\141\x6d\147"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
