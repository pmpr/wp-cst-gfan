<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d611e64f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\x61\170\157\x6e\157\x6d\171\x5f\x73\151\x6e\x67\154\145\x5f\x76\141\154\x75\145\137\x6d\157\144\x69\x66\171\137\151\164\145\x6d\163", [$this, "\x73\143\157\x61\171\x61\x6d\x75\x79\161\147\153\143\x61\x6d\x67"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
