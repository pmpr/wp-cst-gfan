<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11591a79f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\141\x78\157\x6e\x6f\155\171\x5f\x73\151\x6e\147\154\145\x5f\x76\x61\154\x75\145\137\x6d\x6f\144\x69\x66\171\x5f\x69\164\145\x6d\x73", [$this, "\163\x63\157\x61\171\x61\155\165\171\161\147\153\x63\141\x6d\x67"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
