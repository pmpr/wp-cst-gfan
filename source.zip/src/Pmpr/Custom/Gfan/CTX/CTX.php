<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8776d9e6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\x61\170\x6f\x6e\157\x6d\171\x5f\x73\x69\156\147\x6c\x65\x5f\166\x61\154\165\145\x5f\155\x6f\144\x69\146\171\x5f\151\164\145\155\163", [$this, "\x73\143\x6f\141\x79\141\x6d\165\171\x71\147\x6b\x63\x61\155\x67"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
