<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d98ca8b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\x61\x78\157\x6e\x6f\155\x79\x5f\x73\x69\x6e\147\154\x65\x5f\x76\141\154\165\145\x5f\x6d\157\x64\151\x66\x79\x5f\x69\164\x65\155\x73", [$this, "\x73\143\x6f\x61\x79\x61\155\x75\171\161\x67\153\143\x61\155\x67"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = self::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = self::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
