<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a4f27f9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\Woocommerce; use Pmpr\Custom\Gfan\Container; abstract class Common extends Container { }
