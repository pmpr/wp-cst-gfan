<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe938571             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\Woocommerce; use Pmpr\Custom\Gfan\Container; abstract class Common extends Container { }
