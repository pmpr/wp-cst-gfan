<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae868b94f7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\Woocommerce; use Pmpr\Custom\Gfan\Container; abstract class Common extends Container { }
