<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d611e64f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Invoice::symcgieuakksimmu(); } }
