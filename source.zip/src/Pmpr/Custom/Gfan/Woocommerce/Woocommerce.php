<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe938571             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Invoice::symcgieuakksimmu(); } }
