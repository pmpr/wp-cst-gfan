<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d98ca8b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Invoice::symcgieuakksimmu(); } }
