<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d98ca8b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
