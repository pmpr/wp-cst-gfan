<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf74c00e8e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
