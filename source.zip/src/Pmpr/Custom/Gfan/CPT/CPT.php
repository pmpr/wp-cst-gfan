<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11591a79f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CPT; use Pmpr\Custom\Gfan\Container; class CPT extends Container { public function mameiwsayuyquoeq() { FarmTour::symcgieuakksimmu(); } }
