<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d611e64f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CPT; use Pmpr\Custom\Gfan\Container; class CPT extends Container { public function mameiwsayuyquoeq() { FarmTour::symcgieuakksimmu(); } }
