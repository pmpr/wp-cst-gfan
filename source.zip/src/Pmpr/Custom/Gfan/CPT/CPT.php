<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d98ca8b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CPT; use Pmpr\Custom\Gfan\Container; class CPT extends Container { public function mameiwsayuyquoeq() { FarmTour::symcgieuakksimmu(); } }
