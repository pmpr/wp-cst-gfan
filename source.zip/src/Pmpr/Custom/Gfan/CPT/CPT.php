<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe938571             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CPT; use Pmpr\Custom\Gfan\Container; class CPT extends Container { public function mameiwsayuyquoeq() { FarmTour::symcgieuakksimmu(); } }
