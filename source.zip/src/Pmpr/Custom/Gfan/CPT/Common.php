<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707d98ca8b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CPT; use Pmpr\Common\Foundation\CPT; abstract class Common extends CPT { }
