<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11591a79f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CPT; use Pmpr\Common\Foundation\CPT; abstract class Common extends CPT { }
