<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae868b94f7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CPT; use Pmpr\Common\Foundation\CPT; abstract class Common extends CPT { }
