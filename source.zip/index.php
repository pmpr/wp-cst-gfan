<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400a4f27f9             |
    |_______________________________________|
*/
 use Pmpr\Custom\Gfan\Gfan; Gfan::symcgieuakksimmu();
